from django.urls import path
from employees import views

urlpatterns = [
    path("", views.home, name="home"),
    path("api/employees/", views.employee_list_create, name="employee_list_create"),
    path("api/employees/<int:employee_id>/", views.employee_detail, name="employee_detail"),
]
